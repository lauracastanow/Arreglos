
package ordenamiento;

public class Calculos {
 public double media(double[] v){
         double res=0;
         for(int i=0; i<v.length; i++){
             res+=v[i];
         }
         return res/v.length;
     }   
    public double moda(double[]v){
        double cont=0;
        double num=0;
        for(int i=0;i<v.length; i++){
            int aux=0;
            for(int j=0; j<v.length;j++){
                if(v[i]==v[j]) aux++;
            }
            if(aux>=cont){
                cont=aux;
                num=v[i];
            }
        }
        return num;
    }
    
    public  double desviacionestandar(double[] v){
        double res=Math.sqrt(varianza(v));
        return res;
    }
    public  double varianza(double[] v){
        double m=media(v);
        double sum=0;
        for(int i=0; i<v.length; i++){
            sum+=Math.pow(m,2.0);
        }
        return sum/v.length-Math.pow(m, 2.0);
    }

    String media(int[] numerosAleatorios) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String moda(int[] numerosAleatorios) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String varianza(int[] numerosAleatorios) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String desviacionestandar(int[] numerosAleatorios) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

      
}
