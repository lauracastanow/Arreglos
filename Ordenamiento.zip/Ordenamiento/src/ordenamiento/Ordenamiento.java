
package ordenamiento;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Ordenamiento {

    public static void main(String[] args) {   
            
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese la cantidad de números aleatorios a generar: ");
        int cantidadNumeros = scanner.nextInt();


        int[] numerosAleatorios = new int[cantidadNumeros];

        
        Random random = new Random();
        for (int i = 0; i < cantidadNumeros; i++) {
            numerosAleatorios[i] = random.nextInt(100); 
        }

        
        System.out.println("Los números aleatorios generados son:");
        for (int numero : numerosAleatorios) {
            System.out.println(numero);
        }

        
        System.out.println("Ingrese la operación estadística que desea calcular:");
        System.out.println("1 - Media");
        System.out.println("2 - Moda");
        System.out.println("3 - Varianza");
        System.out.println("4 - Desviación estándar");
        int opcion = scanner.nextInt();

        
        switch (opcion) {
            case 1:
                // Calcular la media
                
                double media = Arrays.stream(numerosAleatorios).average().orElse(Double.NaN);
                System.out.println("La media es: " + media);
                break;
            case 2:
                // Calcular la moda
                int moda = 0;
                int repeticionesModa = 0;
                for (int numero : numerosAleatorios) {
                    int repeticiones = 0;
                    for (int i = 0; i < cantidadNumeros; i++) {
                        if (numerosAleatorios[i] == numero) {
                            repeticiones++;
                        }
                    }
                    if (repeticiones > repeticionesModa) {
                        repeticionesModa = repeticiones;
                        moda = numero;
                    }
                }
                System.out.println("La moda es: " + moda);
                break;
            case 3:
                
                media = Arrays.stream(numerosAleatorios).average().orElse(Double.NaN);
                double sumaCuadradosDesviacion = 0;
                for (int numero : numerosAleatorios) {
                    sumaCuadradosDesviacion += Math.pow(numero - media, 2);
                }
                double varianza = sumaCuadradosDesviacion / cantidadNumeros;
                System.out.println("La varianza es: " + varianza);
                break;
            case 4:
                // Calcular la desviación estándar
                media = Arrays.stream(numerosAleatorios).average().orElse(Double.NaN);
                sumaCuadradosDesviacion = 0;
                for (int numero : numerosAleatorios) {
                    sumaCuadradosDesviacion += Math.pow(numero - media, 2);
                }
                double desviacionEstandar = Math.sqrt(sumaCuadradosDesviacion / cantidadNumeros);
                System.out.println("La desviación estándar es: " + desviacionEstandar);
                break;
            default:
                System.out.println("La opción ingresada no es válida");
                break;
        }
     
  }
}
