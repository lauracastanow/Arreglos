
package ordenamiento;
import java.util.Random;

public class Aleatorio {
   public static int generateRandomNumber(int n)

    {
        if (n < 0) {
            throw new IllegalArgumentException("n no debe ser negativo");
        }
        // generar un número aleatorio entre 0 y `n`
        return new Random().nextInt(n + 1);
    } 
}
