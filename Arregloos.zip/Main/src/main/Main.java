
package main;
import java.util.*;

public class Main {

    public static void main(String[] args) {
       
        int n;
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Indique el tamaño del arreglo: ");
        n=scanner.nextInt();
        System.out.println();
        scanner.nextLine();
        
        Vehiculo[] misVehiculos = new Vehiculo[n];
        
        String marca; 
        String modelo;
        String color;
        int kilometraje;
        for(int i=0; i<n;i++){
            System.out.println("Marca: ");
            marca = scanner.nextLine();
            System.out.println();
            
            System.out.println("Modelo: ");
            modelo = scanner.nextLine();
            System.out.println();
            
            System.out.println("Color: ");
            color = scanner.nextLine();
            System.out.println();
            
            System.out.println("Kilometraje: ");
            kilometraje = scanner.nextInt();
            scanner.nextLine();
            System.out.println();
            
            Vehiculo nuevoVehiculo = new Vehiculo(marca, modelo, color, kilometraje);
            misVehiculos[i] = nuevoVehiculo;
            System.out.println("¡Nuevo carro creado!");
        }
        
        int i=1;
        for(Vehiculo Vehi: misVehiculos){
            System.out.print("Mi vehículo #");
            System.out.println(i);
            System.out.println(Vehi.getMarca());
            System.out.println(Vehi.getModelo());
            System.out.println(Vehi.getColor());
            System.out.println(Vehi.getKilometraje());
            System.out.println();
            i++;
        }
        Merge.sort(misVehiculos, 0, n-1);
        Merge.printArray(misVehiculos);
    }
    
}
